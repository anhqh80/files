import sys
import time, datetime

class pmac211():
    
    def __init__(self, unit=1, rtu=None):
        self.rtu = rtu
        self.unit = unit
        
    def set_unit(self, unit):
        self.unit = unit
            
    def read_register(self, reg=1, len=1):
        tag = {'unit':self.unit, 'func': 3, 'add': int(reg)-1, 'len': len, 'value': None, 'err': 0}
        self.rtu.read(tag)
        return tag
        
    def write_register(self, reg=1, len=1, value=""):
        tag = {'unit':self.unit, 'func': 16, 'add': int(reg)-1, 'len': len, 'value': value, 'err': 0}
        self.rtu.write(tag)
        return tag
        
    def read_u16_factor(self, reg):
        add = reg
        if reg >= 40001:
            add = add - 40000
        tag= self.read_register(add, 1)
        tag["value"] = self.rtu.convert_data("u16", tag["value"])
        return tag
        
    def read_u16_factor01(self, reg):
        add = reg
        if reg >= 40001:
            add = add - 40000
        tag= self.read_register(add, 1)
        tag["value"] = self.rtu.convert_data("u16", tag["value"]) * 0.1
        return tag
        #LinhND - add more
    def read_u16_factor001(self, reg):
        add = reg
        if reg >= 40001:
            add = add - 40000
        tag= self.read_register(add, 1)
        tag["value"] = self.rtu.convert_data("u16", tag["value"]) * 0.01
        return tag
    
    def read_u16_factor0001(self, reg):
        add = reg
        if reg >= 40001:
            add = add - 40000
        tag= self.read_register(add, 1)
        tag["value"] = self.rtu.convert_data("u16", tag["value"]) * 0.001
        return tag
        
    def read_s32_factor01(self, reg):
        add = reg
        if reg >= 40001:
            add = add - 40000
        tag= self.read_register(add, 2)
        tag["value"] = self.rtu.convert_data("s32", tag["value"], 'big_swap') * 0.1
        return tag
    
    def read_u32_factor01(self, reg):
        add = reg
        if reg >= 40001:
            add = add - 40000
        tag= self.read_register(add, 2)
        tag["value"] = self.rtu.convert_data("u32", tag["value"], 'big_swap') * 0.1
        return tag
        
    def write_u16(self, reg, value):
        value = int(value)
        add = reg
        if reg >= 40001:
            add = add - 40000
        tag= self.write_register(add, 1, value)
        return tag
        
    #public function.
    def read_data(self, reg):
        return self.table[reg](self, reg)
        
    def write_data(self, reg, value):
        return self.table[reg](self, reg, value)
        
    table = {
        40001: read_u16_factor01, # read Va
        40002: read_u16_factor01, # read Vb
        40003: read_u16_factor01, # read Vc
        
        40010: read_u16_factor001,
        40011: read_u16_factor01,
        40012: read_u16_factor01,
        40013: read_u16_factor01,
        40014: read_u16_factor01,
        40015: read_u16_factor01,
        40016: read_u16_factor01,
        40017: read_u16_factor01,
        40018: read_u16_factor01,
        40019: read_u16_factor01,
        40020: read_u16_factor01,
        40021: read_u16_factor01,
        40022: read_u16_factor01,
        
        40027: read_s32_factor01,
        40029: read_s32_factor01,
        40031: read_s32_factor01,
        40033: read_s32_factor01,
        40035: read_s32_factor01,
        40037: read_s32_factor01,
        40039: read_s32_factor01,
        40041: read_s32_factor01,
        40043: read_s32_factor01,
        40045: read_s32_factor01,
        40047: read_s32_factor01,
        40049: read_s32_factor01,
        40051: read_s32_factor01,
        40053: read_s32_factor01,
        40055: read_s32_factor01,
        40057: read_s32_factor01,
        40061: read_s32_factor01,
        40063: read_s32_factor01,
        40065: read_s32_factor01,
        40067: read_s32_factor01,
        40069: read_s32_factor01,
        40071: read_s32_factor01,
        40073: read_s32_factor01,
        40075: read_s32_factor01,
        40077: read_s32_factor01,
        40078: read_s32_factor01,
        40081: read_s32_factor01,
        40083: read_s32_factor01,
        40085: read_s32_factor01,
        40087: read_s32_factor01,
        40089: read_s32_factor01,
        40091: read_u16_factor0001,
        40092: read_u16_factor0001,
        40093: read_u16_factor0001,
        40094: read_u16_factor0001,
        40095: read_u16_factor0001,
        40096: read_u16_factor0001,
        40097: read_u16_factor0001,
        40098: read_u16_factor0001,
        40099: read_u16_factor0001,
        40100: read_u16_factor0001,
        40101: read_u16_factor0001,
        40102: read_u16_factor0001,
        40103: read_u16_factor0001,
        40104: read_u16_factor0001,
        40105: read_u16_factor0001,
        40106: read_u16_factor0001,
        40107: read_u32_factor01,
        40109: read_u32_factor01,
        40111: read_u32_factor01,
        40113: read_u32_factor01,
        40115: read_u32_factor01,
        40117: read_u32_factor01,
        40119: read_u32_factor01,
        40121: read_u32_factor01,
        40123: read_u32_factor01,
        40125: read_u32_factor01,
        40127: read_u32_factor01,
        40129: read_u32_factor01,
        40131: read_u32_factor01,
        40133: read_u32_factor01,
        40135: read_u32_factor01,
        40137: read_u32_factor01,
        
        40201: read_u32_factor01,
        40203: read_u32_factor01,
        40205: read_u32_factor01,
        40207: read_u32_factor01,
        40209: read_u32_factor01,
        40211: read_u32_factor01,
        40213: read_u32_factor01,
        40215: read_u32_factor01,
        40217: read_u32_factor01,
        40219: read_u32_factor01,
        40221: read_u32_factor01,
        40223: read_u32_factor01,
        40225: read_u32_factor01,
        40227: read_u32_factor01,
        40229: read_u32_factor01,
        40231: read_u32_factor01,
        #energy
        40265: read_u32_factor01,
        40267: read_u32_factor01,
        40269: read_u32_factor01,
        40271: read_u32_factor01,
        40273: read_u32_factor01,
        40275: read_u32_factor01,
        40277: read_u32_factor01,
        40279: read_u32_factor01,
        40281: read_u32_factor01,
        40283: read_u32_factor01,
        40285: read_u32_factor01,
        40287: read_u32_factor01,
        40289: read_u32_factor01,
        40291: read_u32_factor01,
        40293: read_u32_factor01,
        40295: read_u32_factor01,
        #configuration
        45004: read_u16_factor,
        
        #write function
        45201: write_u16,   #Clear Energy Store.
        45210: write_u16,   #Set default setting.
    }
    #LinhND add for new device
class spm91():
    
    def __init__(self, unit=1, rtu=None):
        self.rtu = rtu
        self.unit = unit
        
    def set_unit(self, unit):
        self.unit = unit
            
    def read_register(self, reg=1, len=1):
        tag = {'unit':self.unit, 'func': 3, 'add': int(reg)-1, 'len': len, 'value': None, 'err': 0}
        self.rtu.read(tag)
        return tag
        
    def write_register(self, reg=1, len=1, value=""):
        tag = {'unit':self.unit, 'func': 16, 'add': int(reg)-1, 'len': len, 'value': value, 'err': 0}
        print(tag)
        self.rtu.write(tag)
        return tag
        
    def read_u16_factor(self, reg):
        add = reg
        if reg >= 40001:
            add = add - 40000
        tag= self.read_register(add, 1)
        tag["value"] = self.rtu.convert_data("u16", tag["value"])
        return tag
        
    def read_u16_factor01(self, reg):
        add = reg
        if reg >= 40001:
            add = add - 40000
        tag= self.read_register(add, 1)
        tag["value"] = self.rtu.convert_data("u16", tag["value"]) * 0.1
        return tag
        
    def read_u16_factor001(self, reg):
        add = reg
        if reg >= 40001:
            add = add - 40000
        tag= self.read_register(add, 1)
        tag["value"] = self.rtu.convert_data("u16", tag["value"]) * 0.01
        return tag
    
    def read_u16_factor0001(self, reg):
        add = reg
        if reg >= 40001:
            add = add - 40000
        tag= self.read_register(add, 1)
        tag["value"] = self.rtu.convert_data("u16", tag["value"]) * 0.001
        return tag
        
    def read_s32_factor01(self, reg):
        add = reg
        if reg >= 40001:
            add = add - 40000
        tag= self.read_register(add, 2)
        tag["value"] = self.rtu.convert_data("s32", tag["value"], 'big_swap') * 0.1
        return tag
    
    def read_u32_factor01(self, reg):
        add = reg
        if reg >= 40001:
            add = add - 40000
        tag= self.read_register(add, 2)
        tag["value"] = self.rtu.convert_data("u32", tag["value"], 'big_swap') * 0.1
        return tag
    
    def read_u32_factor001(self, reg):
        add = reg
        if reg >= 40001:
            add = add - 40000
        tag= self.read_register(add, 2)
        tag["value"] = self.rtu.convert_data("u32", tag["value"], 'big_swap') * 0.01
        return tag
        
    def read_u32_factor0001(self, reg):
        add = reg
        if reg >= 40001:
            add = add - 40000
        tag= self.read_register(add, 2)
        tag["value"] = self.rtu.convert_data("u32", tag["value"], 'big_swap') * 0.001
        return tag
        
    def write_u16(self, reg, value):
        value = int(value)
        add = reg
        if reg >= 40001:
            add = add - 40000
        tag= self.write_register(add, 1, value)
        return tag
        
    #public function.
    def read_data(self, reg):
        return self.table[reg](self, reg)
        
    def write_data(self, reg, value):
        return self.table[reg](self, reg, value)
        
    table = {
        40001: read_u32_factor01,
        40003: read_u16_factor001,
        40004: read_u32_factor0001,
        40006: read_u32_factor01,
        40008: read_u32_factor01,
        40010: read_u32_factor01,
        40012: read_u16_factor001,
        40013: read_u16_factor0001,
        40014: read_u32_factor01,
        40016: read_u32_factor01,
        
        40020: read_u32_factor01,
        40022: read_u32_factor01,
        40024: read_u32_factor01,
        
        
        #energy
        40201: read_u16_factor,
        40202: read_u16_factor,
        40203: read_u16_factor,
        40207: read_u16_factor,
        40251: read_u16_factor,
    }