#!/usr/bin/python
#from pynodes import read_all, read_tag, read_tags
import sys

# for testing
# for testing
print ('Number of arguments:', len(sys.argv), 'arguments.')
print ('Argument List:', str(sys.argv))

# print("****Read all***********")
# rets = read_all()
# print(rets)

# print("****Read tag***********")
# tag = {
    # "id":"66600032032002.3503235.40001",
    # "att": "Voltage",
    # "type": 2,
    # "ctt": "2019-09-23T12:00:00",
    # "lmt": "2019-09-23T12:00:00",
# }
# tag2 = {
    # "id":"66600032032002.3503235.40002",
    # "att": "Voltage",
    # "type": 2,
    # "ctt": "2019-09-23T12:00:00",
    # "lmt": "2019-09-23T12:00:00",
# }
# rets = read_tag(tag)
# print(rets)

# print("****Read tags***********")
# tags = [tag, tag2]
# rets = read_tags(tags)
# print(rets)

tagw = [{
    "id":"66600032032002.3503235.45201",
    "value": "201",
    "type": 1
},
{
    "id":"66600032032002.3503235.45210",
    "value": "201",
    "type": 1
}
]

##
'''
python.exe .\pyWrite.py '[{\"id\": \"66600032032002.3503235.45
201\",\"value\": \"201\",\"type\":1},{\"id\":\"66600032032002.3503235.45210\",
\"value\":\"201\",\"type\": 1}]'

[{\"id\": \"66600032032002.3503235.45201\",\"value\": \"201\",\"type\":1},{\"id\":\"66600032032002.3503235.45210\",\"value\":\"201\",\"type\": 1}]

'[{\"id\": \"66600032032002.3503235.40001\",\"type\":1},{\"id\":\"66600032032002.3503235.40002\",\"type\": 1}]'
'''

import os
#os.system("C:\Users\Thinkpad\Anaconda3\python.exe pyWrite.py tagw")
os.system("c:\\users\\thinkpad\\anaconda3\\python pyWrite.py \"[{\"id\": \"66600032032002.3503235.45201\", \"value\": \"201\",\"type\":1},{\"id\":\"66600032032002.3503235.45210\",\"value\":\"201\",\"type\": 1}]\"")
