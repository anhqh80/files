import json

def writeToJSONFile(path, data):
    filePathNameWExt =  path
    with open(filePathNameWExt, 'w') as fp:
        json.dump(data, fp)

def readFromJSONFile(path):
    filePathNameWExt = path
    with open(filePathNameWExt, 'r') as json_data:
        d = json.load(json_data)
        #print(d)
        return d

devices = readFromJSONFile("/opt/bee/devices.cfg")
wdevices = readFromJSONFile("/opt/bee/wdevices.cfg")