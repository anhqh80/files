# sử dụng:
1. module config.py
- Lưu thiết lập cho các script khác sử dụng:
- Các thông số đang cấu hình:
+   Communicate:
++      port: cổng serial sử dụng cho phần cứng. Với Gateway sử dụng '/dev/ttyS0' cho zigbee, '/dev/ttyS1' cho rf433
++      baud: tốc độ đường truyền.
+   common:
        loging: quản lý log cho ứng dụng.

2. Module rtu.py
- driver theo chuẩn modbus RTU, hỗ trợ các lệnh đọc/ghi dữ liệu qua modbus RTU.
- Ứng dụng sử dụng thông tin communicate trong file config.py
- Sử dụng:
    client = rtu()
    client.connect()
    
3. module pilot.py
- Driver đọc/ghi dữ liệu với thiết bị của hãng pilot.
- Đang hỗ trợ các thiết bị:
+   pmac211
++      Thư viện sử dụng driver rtu để giao tiếp.
- Sử dụng:
    # đã khởi tạo object rtu từ driver rtu.
    pilot = pilot.pmac211(unit=1, rtu=rtu)

4. file devices.cfg
- Mapping item từ ứng dụng platform với device thực tế.
- Cấu trúc:
+   Phần định danh với platform:
    {
        "id":"66600032032002.3503235.40001",
        "att": "Voltage",
        "type": 2,
        "ctt": "2019-09-23T12:00:00",
        "lmt": "2019-09-23T12:00:00",
    }
+   Phần định danh với thiết bị:
    {
        "device": {
            "name": "pmac211",
            "unit": 6,
            "param": "40001"
        }
    }
- Với mỗi device, phần định danh sẽ khác nhau.

5. file wdevices.cfg
- Mapping item từ ứng dụng platform với device thực tế.
- Cấu trúc:
+   Phần định danh với platform:
    {
        "id":"66600032032002.3503235.40001",
        "att": "Voltage",
        "type": 2,
        "ctt": "2019-09-23T12:00:00",
        "lmt": "2019-09-23T12:00:00",
    }
+   Phần định danh với thiết bị:
    {
        "device": {
            "name": "pmac211",
            "unit": 6,
            "param": "40001"
        }
    }
- Với mỗi device, phần định danh sẽ khác nhau.

6. module pynodes.py
- Ứng dụng đọc dữ liệu của bất kỳ thiết bị nào được cấu hình trong file devices.cfg.
- Cung cấp các function read_tag, read_all, read_tags để đọc dữ liệu.
- Sử dụng:
    call: python pynodes.py list_tags_json
    output: list_tags_json_with_data.
    ví dụ đọc 2 tags:
        call: python pynodes.py '[{\"id\": \"66600032032002.3503235.40001\",\"type\":1},{\"id\":\"66600032032002.3503235.40002\",\"type\": 1}]'
        
        output: [{'id': '66600032032002.3503235.40001', 'type': 2, 'att': 'Voltage', 'v': '1.1', 'err': 0, 't': '1568802417'}, {'id': '66600032032002.3503235.40002', 'type': 2, 'att': 'Voltage', 'v': '3.5', 'err': 0, 't': '1568802418'}]
        
    ví dụ đọc all theo file devices.cfg:
        call: python pynodes.py
        
        output: [{'id': '66600032032002.3503235.40001', 'type': 2, 'att': 'Voltage', 'v': '1.1', 'err': 0, 't': '1568802417'}, {'id': '66600032032002.3503235.40002', 'type': 2, 'att': 'Voltage', 'v': '3.5', 'err': 0, 't': '1568802418'}]
        
7. module pywrite.py
- Ứng dụng đọc dữ liệu của bất kỳ thiết bị nào được cấu hình trong file wdevices.cfg.
- Cung cấp các function write_tags để đọc dữ liệu.
- Sử dụng:
    call: python pywrite.py list_tags_json
    output: list_tags_json_with_respond_status.
    ví dụ:
        call: python pywrite.py [{\"id\": \"66600032032002.3503235.45201\",\"value\": \"201\",\"type\":1},{\"id\":\"66600032032002.3503235.45210\",\"value\":\"201\",\"type\": 1}]
        
        output: [{"id": "66600032032002.3503235.45201", "type": 1, "att": "Clear Energy", "v": "201", "err": 0, "t": "1568802094"}, {"id": "66600032032002.3503235.45210", "type": 1, "att": "Default system", "v": "201", "err": 0, "t": "1568802095"}]
        
    Ví dụ xóa dữ liệu năng lượng:
        python pywrite.py [{\"id\": \"66600032032002.3503235.45201\",\"value\": \"201\",\"type\":1}]
        output: [{"id": "66600032032002.3503235.45201", "type": 1, "att": "Clear Energy", "v": "201", "err": 0, "t": "1568802094"}]
        
        nếu trên linux, sử dụng:
        ./pyWrite.py '[{"id": "66600032032002.3503235.45201","value": "201","type":1}]'