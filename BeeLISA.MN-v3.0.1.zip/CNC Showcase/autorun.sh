#!/bin/sh
while true
do
                ps | grep -v grep | grep IoTGatewayApp
                if [ $? -eq 0 ]; then
                 echo "IOTGatewayApp is running."
                else
                  echo "IOTGatewayApp is not running."
                  /opt/bee/IoTGatewayApp >>  /tmp/bee1.log &
                fi
                sleep 1
done

