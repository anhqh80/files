communicate = {
    "port": "COM25",
    "baud": "9600",
}

common = {
    "log": "pyNod.log"
}