free && sync && echo 3 > /proc/sys/vm/drop_caches && echo "" && free
