#!/usr/bin/python

from rtu import rtu
from devices import wdevices

import sys, json
import time, datetime

import pilot

from config import common

rtu = rtu()
rtu.connect()
pmac211 = pilot.pmac211(unit=1, rtu=rtu)

def write(dev):
    try:
        proto = dev['device']
        if proto['name'] == 'pmac211':
            pmac211.set_unit(int(proto['unit']))
            tag = pmac211.write_data(int(proto['param']), dev['value'])
            time.sleep(.05)
        
        ret = {"id": dev["id"], "type": dev["type"], "att": dev["att"], 'v': str(dev['value']), 'err': tag['err'], 't': str(int(time.time()))}
        
        return ret
    except Exception as ex:
        pass

def write_tag(tag):
    sid = tag["id"]
    tag['err'] = 1
    for item in wdevices:
        if sid == item["id"]:
            item['value'] = tag['value']
            ret = write(item)
            return ret
    return tag
    
def write_tags(tags):
    rets = []
    for tag in tags:
        ret = write_tag(tag)
        rets.append(ret)
    return json.dumps(rets)

if __name__ == "__main__":
    arg = None
    if len(sys.argv) >= 2:
        arg = json.loads(sys.argv[1])
        ret = write_tags(arg)
        print(ret)
    sys.exit()