from config import communicate
from pymodbus.client.sync import ModbusSerialClient as ModbusClient
from pymodbus.constants import Endian
from pymodbus.payload import BinaryPayloadDecoder

class rtu():
    def __init__(self):
        self.rtu = ModbusClient(method='rtu', port=communicate.get('port'), timeout=1.5, baudrate=int(communicate.get('baud')))
    
    def connect(self):
        try:
            self.rtu.connect()
        except Exception as e:
            raise e
            
    def read(self, tag):
        f = int(tag['func'])
        a = int(tag['add'])
        l = int(tag['len'])
        u = int(tag['unit'])
        try:
            if f == 1:
                t = self.rtu.read_coils(a, l, unit=(u))
                tag['value'] = t.bits
            elif f == 2:
                t = self.rtu.read_discrete_inputs(a, l, unit=(u))
                tag['value'] = t.bits
            elif f == 3:
                t = self.rtu.read_holding_registers(a, l, unit=(u))
                tag['value'] = t.registers
            elif f == 4:
                t = self.rtu.read_input_registers(a, l, unit=(u))
                tag['value'] = t.registers
            tag['err'] = 0
        except:
            tag['err'] = 1
            
        return tag
        
    def reads(self, tags):
        rets = []
        for tag in tags:
            rets.append(self.read(tag))
        return rets
        
    def convert_data(self, dataformat, raw_value, order='big'):
        decoder = None
        if order == 'big':
            if len(raw_value) >= 2:
                decoder = BinaryPayloadDecoder.fromRegisters(raw_value, byteorder=Endian.Big,
                                                 wordorder=Endian.Big)
            else:
                decoder = BinaryPayloadDecoder.fromRegisters(raw_value, byteorder=Endian.Big)
        elif order == 'little':
            if len(raw_value) >= 2:
                decoder = BinaryPayloadDecoder.fromRegisters(raw_value, byteorder=Endian.Little,
                                                 wordorder=Endian.Little)
            else:
                decoder = BinaryPayloadDecoder.fromRegisters(raw_value, byteorder=Endian.Big)
        elif order == 'big_swap':
            if len(raw_value) >= 2:
                decoder = BinaryPayloadDecoder.fromRegisters(raw_value, byteorder=Endian.Big,
                                                 wordorder=Endian.Little)
            else:
                decoder = BinaryPayloadDecoder.fromRegisters(raw_value, byteorder=Endian.Big)
        elif order == 'little_swap':
            if len(raw_value) >= 2:
                decoder = BinaryPayloadDecoder.fromRegisters(raw_value, byteorder=Endian.Little,
                                                 wordorder=Endian.Big)
            else:
                decoder = BinaryPayloadDecoder.fromRegisters(raw_value, byteorder=Endian.Big)
                
        if dataformat == "bit":   # BIT
            return decoder.decode_bits()
        elif dataformat == "s8":   # BYTE
            return decoder.decode_8bit_int()
        elif dataformat == "u8":   # UBYTE
            return decoder.decode_8bit_uint()
        elif dataformat == "s16":   # SHORT
            return decoder.decode_16bit_int()
        elif dataformat == "u16":   # USHORT
            return decoder.decode_16bit_uint()
        elif dataformat == "s32":   # INT32
            return decoder.decode_32bit_int()
        elif dataformat == "u32":   # UINT32
            return decoder.decode_32bit_uint()
        elif dataformat == "s64":   # INT64
            return decoder.decode_64bit_int()
        elif dataformat == "u64":   # UINT64
            return decoder.decode_64bit_uint()
        elif dataformat == "float":   # FLOAT
            return decoder.decode_32bit_float()
        elif dataformat == "double":   # DOUBLE
            return decoder.decode_64bit_float()
            
        return raw_value
        
    def write(self, tag):
        f = int(tag['func'])
        a = int(tag['add'])
        l = int(tag['len'])
        u = int(tag['unit'])
        v = int(tag['value'])
        try:
            if f == 5:
                t = self.rtu.write_coil(a, [v], unit=(u))
            elif f == 6:
            #write_register(1, 10, unit=UNIT)
                t = self.rtu.write_register(a, v, unit=(u))
            elif f == 15:
                t = self.rtu.write_coils(a, l*[v], unit=(u))
            elif f == 16:
                t = self.rtu.write_registers(a, l*[v], unit=(u))
                
            if (t.function_code < 0x80):
                tag['err'] = 0
                return tag
                
            tag['err'] = 1
        except:
            tag['err'] = 1
            
        return tag
