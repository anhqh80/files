#!/usr/bin/python

from rtu import rtu
from devices import devices

import sys, json
import time, datetime

import pilot
import logging
from logging.handlers import RotatingFileHandler

from config import common

log_formatter = logging.Formatter('%(asctime)s %(levelname)s %(funcName)s(%(lineno)d) %(message)s')
my_handler = RotatingFileHandler(common.get("log"), mode='a', maxBytes=50*1024, backupCount=1, encoding=None, delay=0)
my_handler.setFormatter(log_formatter)
my_handler.setLevel(logging.INFO)

app_log = logging.getLogger('pyNode')
app_log.setLevel(logging.INFO)
app_log.addHandler(my_handler)

rtu = rtu()
try:
    rtu.connect()
except Exception as e:
    app_log.error(str(e))

pmac211 = pilot.pmac211(unit=1, rtu=rtu)
spm91 = pilot.spm91(unit=1, rtu=rtu)

def read(dev):
    ret = {"id": dev["id"], "type": dev["type"], "att": dev["att"], 'v': "0", 'err': 1, 't': str(int(time.time()))}
    try:
        proto = dev['device']
        if proto['name'] == 'pmac211':
            pmac211.set_unit(int(proto['unit']))
            tag = pmac211.read_data(int(proto['param']))
            time.sleep(.05)
        elif proto['name'] == 'spm91':
            spm91.set_unit(int(proto['unit']))
            tag = spm91.read_data(int(proto['param']))
            time.sleep(.05)
        
        ret['v'] = str(tag['value'])
        ret['err'] = tag['err']
        
        return ret
    except Exception as ex:
        app_log.warning(str(ex))
        app_log.warning("unkown param: " + proto["param"])
        return ret

def read_all():
    rets = []
    for dev in devices:
        ret = read(dev)
        rets.append(ret)
    app_log.info(rets)
    return json.dumps(rets)
            
def read_tag(tag):
    sid = tag["id"]
    for item in devices:
        if sid == item["id"]:
            ret = read(item)
            return ret
    tag['err'] = 1
    return tag
    
def read_tags(tags):
    rets = []
    for tag in tags:
        ret = read_tag(tag)
        rets.append(ret)
            
    app_log.info(rets)
    return json.dumps(rets)

def process(devs=None):
    if devs is None:
        return read_all()
        
    return read_tags(devs)

if __name__ == "__main__":
    arg = None
    if len(sys.argv) >= 2:
        arg = json.loads(sys.argv[1])
    ret = process(arg)
    print(ret)
    sys.exit()